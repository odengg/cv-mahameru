# Website CV Mahameru Drum

Website company profile dan katalog statis untuk CV Mahameru Drum. Dibangun menggunakan HTML, CSS, dan JavaScript biasa tanpa framework atau build step.

## Isi proyek

- `index.html` — konten utama, metadata SEO, dan informasi bisnis
- `styles.css` — desain responsif
- `script.js` — menu mobile, filter katalog, pencarian, dan tahun footer
- `assets/images/` — logo, referensi katalog, materi produk yang diberikan, dan crop ilustrasi produk untuk kartu katalog
- `robots.txt` dan `sitemap.xml` — file awal untuk SEO

## Jalankan di komputer

Cara sederhana: buka `index.html` di browser. Untuk pengujian yang lebih baik, gunakan ekstensi Live Server di VS Code atau jalankan server lokal seperti `python -m http.server 8000`, lalu buka `http://localhost:8000`.

## Sebelum publish

1. Ganti `https://YOUR-SITE-URL.example/` pada `index.html`, `robots.txt`, dan `sitemap.xml` dengan URL website publik yang sebenarnya.
2. Periksa seluruh gambar, teks, tautan WhatsApp, TikTok, Shopee, dan alamat.
3. Pastikan informasi jam operasional sesuai. Hari operasional belum dikonfirmasi; jangan membuat klaim hari buka yang tidak benar.
4. Periksa kembali setiap gambar produk. Gambar katalog berasal dari materi ilustrasi dan bukan konfirmasi stok aktual.
5. Jangan memasukkan harga, jumlah stok, sertifikasi, atau klaim kecocokan bahan tanpa data terverifikasi.

## Upload ke GitHub

1. Buat repository baru di https://github.com/new.
2. Upload isi folder proyek ini ke root repository, sehingga `index.html` ada langsung di root.
3. Untuk hosting gratis, buka https://pages.cloudflare.com/ dan hubungkan repository GitHub, atau gunakan GitHub Pages.
4. Setelah deployment berhasil, salin URL publik yang diberikan oleh penyedia hosting.
5. Ganti placeholder `YOUR-SITE-URL.example` pada tiga file SEO dengan URL publik yang benar, lalu commit dan push ulang.

## Agar bisa ditemukan di Google

1. Buka https://search.google.com/search-console/.
2. Tambahkan properti URL prefix menggunakan URL publik website.
3. Selesaikan verifikasi kepemilikan sesuai instruksi Google.
4. Submit `https://URL-WEBSITE-ANDA/sitemap.xml` di menu Sitemaps.
5. Gunakan URL Inspection untuk meminta pengindeksan halaman utama.
6. Periksa status indexing di Search Console. Pengindeksan tidak instan dan tidak dijamin.

## Catatan penting

- URL canonical dan sitemap saat ini sengaja menggunakan placeholder; wajib diganti setelah URL hosting diketahui.
- Website ini tidak memiliki backend, sistem stok real-time, checkout, atau API. Tombol WhatsApp membuka percakapan dengan teks yang sudah disiapkan.
- Informasi kapasitas pada kartu merupakan contoh dari materi visual, bukan jaminan produk selalu tersedia.
- Untuk performa dan kepercayaan yang lebih baik, ganti ilustrasi AI/katalog dengan foto aktual barang saat tersedia.
